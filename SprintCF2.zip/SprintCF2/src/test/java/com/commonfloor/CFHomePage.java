package com.commonfloor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CFHomePage {
	WebDriver driver;
	public CFHomePage(WebDriver driver)
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	//Home page
		@FindBy(how=How.XPATH, using="//*[@id=\"citySuggestInputHomePopup\"]")
		@CacheLookup
		public WebElement selectCity;
		
		@FindBy(how=How.XPATH, using="/html/body/div[2]/div[5]/div[9]/div/div/div/div/div[2]/ul/li[9]")
		@CacheLookup
		public WebElement Cityname;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"loginForm\"]/div[4]/div[1]/div/a")
		@CacheLookup
		WebElement CAccount;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"login-name-id\"]")
		@CacheLookup
		WebElement firstName;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"login-email-id\"]")
		@CacheLookup
		WebElement Email;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"login-mobile-id\"]")
		@CacheLookup
		WebElement Mobile;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"login-password-id\"]")
		@CacheLookup
		WebElement Password;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"signup-city\"]")
		@CacheLookup
		WebElement city;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"signup-city-list\"]/li[4]")
		@CacheLookup
		WebElement dcity;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"loginForm\"]/div[7]/div/label[1]")
		@CacheLookup
		WebElement select;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"signupbutton\"]")
		@CacheLookup
		WebElement sbutton;
		

		 public WebElement getCity() { 
			 return selectCity; 
			 } 
		 public WebElement getCityName() { 
			 return Cityname; 
			 }
		 public WebElement getCAccount() { 
			 return CAccount; 
			 } 
		 public WebElement getfirstName() { 
			 return firstName; 
			 }
		 public WebElement getEmail() { 
			 return Email; 
			 } 
		 public WebElement getMobile() { 
			 return Mobile; 
			 }
		 public WebElement getPassword() { 
			 return Password; 
			 } 
		 public WebElement getcity() { 
			 return city; 
			 }
		 public WebElement getdcity() { 
			 return dcity; 
			 } 
		 public WebElement getselect() { 
			 return select; 
			 }
		 public WebElement getsbutton() { 
			 return sbutton; 
			 } 

}
