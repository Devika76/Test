package com.commonfloor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class loginPage {
	WebDriver driver;
	public loginPage(WebDriver driver)
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH, using="//*[@id=\"login-details\"]")
	@CacheLookup
	WebElement SignUp;

	@FindBy(how=How.XPATH, using="//*[@id=\"login-details\"]/ul/li[1]/a")
	@CacheLookup
	WebElement LoginDetails;
	
	@FindBy(how=How.XPATH, using="/html/body/div[9]/div/div/div[2]/div[3]/form/div[1]/input")
	@CacheLookup
	WebElement LoginEmail;
	
	@FindBy(how=How.XPATH, using="//*[@id=\"login-password-id\"]")
	@CacheLookup
	WebElement LoginPass;
	
	@FindBy(how=How.XPATH, using="/html/body/div[9]/div/div/div[2]/div[3]/form/input")
	@CacheLookup
	WebElement LoginButton;
	
	 public WebElement getSignUpB() { 
		 return SignUp; 
		 }
	
	 public WebElement getLoginDetails() { 
		 return LoginDetails; 
		 } 
	 public WebElement getLoginEmail() { 
		 return LoginEmail; 
		 } 
	 public WebElement getLoginPass() { 
		 return LoginPass; 
		 }
	 public WebElement getLoginButton() { 
		 return LoginButton; 
		 } 
}
