package com.commonfloor;

import org.testng.annotations.Test;

public class verifyCFTest {

  @Test
  public void AccountTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void AccountFailTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void AccountNullTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void SelectCityTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void SelectcityfailTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void addBasicDetailsTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void addBasicDetailsfailTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void addLocationDetailsTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void addLocationDetailsFailsTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void addPropertyDetailsTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void addPropertyDetailsFailsTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void loginSuccessTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void loginfailTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void loginfail2Test() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void propertyButtonTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void propertyButtonfailTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void verifyTest() {
    throw new RuntimeException("Test not implemented");
  }
}
