package com.commonfloor;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class verifyCF {
	//static String driverPath = "C:\\Users\\dputtupu\\Downloads\\chromedriver_win32\\";
	WebDriver driver;
	CFHomePage hp;
	loginPage lp;
	ProDetailsPage ap;
	@BeforeMethod
    public void verify() throws InterruptedException {
	    System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 driver.get("https://www.commonfloor.com/");
		 driver.manage().window().maximize(); 
		 Thread.sleep(1500);
		 hp = new CFHomePage(driver);
		 lp = new loginPage(driver);
		 ap = new ProDetailsPage(driver);
	}
	@Test(priority=0) 
	public void Selectcityfail() throws InterruptedException 
	{
		  Thread.sleep(5000); 
		  hp.selectCity.click(); //hp.Cityname.click();
		  Thread.sleep(1500); 
	}
	@Test(priority=0)
    public void SelectCity() throws InterruptedException
    {
    	Thread.sleep(5000);
    	hp.selectCity.click();
    	hp.Cityname.click();
        Thread.sleep(1500);
     }
	 @Test(priority=0) public void AccountNull() throws InterruptedException 
	 {
		  Thread.sleep(5000); 
		  hp.selectCity.click(); 
		  hp.Cityname.click();
		  Thread.sleep(1500); 
		  lp.SignUp.click(); 
		  Thread.sleep(5000);
		  lp.LoginDetails.click(); 
		  hp.CAccount.click(); 
		  hp.sbutton.click(); 
	 }
		  
	  @Test(priority=0) 
	 public void AccountFail() throws InterruptedException 
	 {
		  Thread.sleep(5000); 
		  hp.selectCity.click(); 
		  hp.Cityname.click();
		  Thread.sleep(1500); 
		  lp.SignUp.click(); 
		  Thread.sleep(5000);
		  lp.LoginDetails.click(); 
		  hp.CAccount.click();
		  hp.firstName.sendKeys("Devika"); 
		  hp.Email.sendKeys("abc@gmail.com");
		  hp.Mobile.sendKeys("837419301"); 
		  hp.Password.sendKeys("abc");
		  hp.city.click(); 
		  hp.dcity.click(); 
		  hp.select.click(); 
		  hp.sbutton.click(); 
	 }
	  @Test(priority=0) 
	  public void Account() throws InterruptedException 
	  {
		  Thread.sleep(5000); 
		  hp.selectCity.click(); 
		  hp.Cityname.click();
		  Thread.sleep(1500); 
		  lp.SignUp.click(); 
		  Thread.sleep(5000);
		  lp.LoginDetails.click(); 
		  hp.CAccount.click();
		  hp.firstName.sendKeys("Devika"); 
		  hp.Email.sendKeys("devidevika224@gmail.com");
		  hp.Mobile.sendKeys("8374191301"); 
		  hp.Password.sendKeys("Puttupu@1");
		  hp.city.click(); 
		  hp.dcity.click(); 
		  hp.select.click(); 
		  hp.sbutton.click(); 
	  }
		  
	  @Test(priority=0) 
	  public void loginfail() throws InterruptedException 
	  {
		  Thread.sleep(5000); 
		  hp.selectCity.click(); 
		  hp.Cityname.click();
		  Thread.sleep(5000); 
		  lp.SignUp.click(); 
		  Thread.sleep(5000);
		  lp.LoginDetails.click(); 
		  lp.getLoginEmail().sendKeys(""); 
		  Thread.sleep(1500);
		  lp.getLoginPass().sendKeys(""); 
		  lp.getLoginButton().click();
		  Thread.sleep(5000); 
	  }
		  
	 @Test(priority=1) 
	 public void loginfail2() throws InterruptedException 
	 {
		  Thread.sleep(5000); 
		  hp.selectCity.click(); 
		  hp.Cityname.click();
		  Thread.sleep(5000); 
		  lp.SignUp.click(); 
		  Thread.sleep(5000);
		  lp.LoginDetails.click(); 
		  lp.getLoginEmail().sendKeys("abc123@gmail.com");
		  lp.getLoginPass().sendKeys("abcdefgh"); 
		  lp.getLoginButton().click();
		  Thread.sleep(1500); 
	 }
		  
	 @Test(priority=2) 
	 public void loginSuccess() throws InterruptedException 
	 {
		  Thread.sleep(5000); 
		  hp.selectCity.click(); 
		  hp.Cityname.click();
		  Thread.sleep(5000); 
		  lp.SignUp.click(); 
		  Thread.sleep(5000);
		  lp.LoginDetails.click();
		  lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
		  lp.getLoginPass().sendKeys("Puttupu@1"); 
		  lp.getLoginButton().click();
		  Thread.sleep(1500); 
	 }

	    @Test(priority=3)
	    public void propertyButtonfail() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	  	  	//ap.PostButton.click();
	    }
	    @Test(priority=3)
	    public void propertyButton() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        Thread.sleep(5000);
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	        ap.PostPro.click();
	    }
	    @Test(priority=4)
	    public void addBasicDetailsfail() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	  	  	ap.PostPro.click();
	  	  	//basic details
	  	  	ap.Basicrent.click();
	  	  	ap.ProType.click();
	  	  	//ap.ProTypeLabel.click(); 
	  	  	ap.AvaiDate.click();
	  	  	ap.ADate.click(); 
	  	  	ap.Bcont.click();
	        
	    }
	    @Test(priority=4)
	    public void addBasicDetails() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	  	  	ap.PostPro.click();
	  	  	//basic details
	  	  	ap.Basicrent.click();
	  	  	ap.ProType.click();
	  	  	ap.ProTypeLabel.click(); 
	  	  	ap.AvaiDate.click();
	  	  	ap.ADate.click(); 
	  	  	ap.Bcont.click();
	    }
	    @Test(priority=5)
	    public void addLocationDetailsFails() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	  	  	ap.PostPro.click();
	  	  	//basic details
	  	  	ap.Basicrent.click();
	  	  	ap.ProType.click();
	  	  	ap.ProTypeLabel.click(); 
	  	  	ap.AvaiDate.click();
	  	  	ap.ADate.click(); 
	  	  	ap.Bcont.click();
	  	  	//location details
	  	  	ap.Lcity.click(); 
	  	  	//ap.Scity.click(); 
	  	  	ap.Aname.click();
	  	  	ap.Apname.sendKeys("Vijay Glow, Beant Nagar");
	  	  	ap.Sname.click(); 
	  	  	ap.Lcont.click();
	    }
	    @Test(priority=5)
	    public void addLocationDetails() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	  	  	ap.PostPro.click();
	  	  	//basic details
	  	  	ap.Basicrent.click();
	  	  	ap.ProType.click();
	  	  	ap.ProTypeLabel.click(); 
	  	  	ap.AvaiDate.click();
	  	  	ap.ADate.click(); 
	  	  	ap.Bcont.click();
	  	  	//location details
	  	  	ap.Lcity.click(); 
	  	  	ap.Scity.click(); 
	  	  	ap.Aname.click();
	  	  	ap.Apname.sendKeys("Vijay Glow, Beant Nagar");
	  	  	ap.Sname.click(); 
	  	  	ap.Lcont.click();
	    }
	    @Test(priority=5)
	    public void addPropertyDetailsFails() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	  	  	ap.PostPro.click();
	  	  	//basic details
	  	  	ap.Basicrent.click();
	  	  	ap.ProType.click();
	  	  	ap.ProTypeLabel.click(); 
	  	  	ap.AvaiDate.click();
	  	  	ap.ADate.click(); 
	  	  	ap.Bcont.click();
	  	  	//location details
	  	  	ap.Lcity.click(); 
	  	  	ap.Scity.click(); 
	  	  	ap.Aname.click();
	  	  	ap.Apname.sendKeys("Vijay Glow, Beant Nagar");
	  	  	ap.Sname.click(); 
	  	  	ap.Lcont.click();
	  	  	//property details
	  	  	ap.Norooms.click(); 
	  	  	ap.Nobhk.click();
	  	  	ap.Area.sendKeys("400");
	  	  	ap.Price.sendKeys("8000");
	  	  	ap.Maintenance.sendKeys("500");
	  	  	ap.Deposit.sendKeys("3000");
	  	  	ap.brooms.click();
	  	  	ap.Nobrooms.click(); 
	  	  	ap.FurLabel.click();
	  	  	ap.SemiFur.click();
	  	  	ap.ParkingLabel.click();
	  	  	ap.Parking.click();
	  	  	//ap.Floors.sendKeys("5");
	  	  	ap.FloorNo.sendKeys("3");
	  	  	ap.BalconyLabel.click();
	  	  	ap.NoBalcony.click();
	    } 
	    @Test(priority=5)
	    public void addPropertyDetails() throws InterruptedException
	    {
	    	Thread.sleep(5000);
	    	hp.selectCity.click();
	    	hp.Cityname.click();
	    	Thread.sleep(5000);
	    	lp.SignUp.click();
	        Thread.sleep(5000);
	        lp.LoginDetails.click(); 
	        Thread.sleep(5000);
	        lp.getLoginEmail().sendKeys("devidevika224@gmail.com");
	        lp.getLoginPass().sendKeys("Puttupu@1");
	        Thread.sleep(9000);
	        lp.getLoginButton().click();
	        Thread.sleep(9000);
	  	  	ap.PostPro.click();
	  	  	//basic details
	  	  	ap.Basicrent.click();
	  	  	ap.ProType.click();
	  	  	ap.ProTypeLabel.click(); 
	  	  	ap.AvaiDate.click();
	  	  	ap.ADate.click(); 
	  	  	ap.Bcont.click();
	  	  	//location details
	  	  	ap.Lcity.click(); 
	  	  	ap.Scity.click(); 
	  	  	ap.Aname.click();
	  	  	ap.Apname.sendKeys("Vijay Glow, Beant Nagar");
	  	  	ap.Sname.click(); 
	  	  	ap.Lcont.click();
	  	  	//property details
	  	  	ap.Norooms.click(); 
	  	  	ap.Nobhk.click();
	  	  	ap.Area.sendKeys("400");
	  	  	ap.Price.sendKeys("8000");
	  	  	ap.Maintenance.sendKeys("500");
	  	  	ap.Deposit.sendKeys("3000");
	  	  	ap.brooms.click();
	  	  	ap.Nobrooms.click(); 
	  	  	ap.FurLabel.click();
	  	  	ap.SemiFur.click();
	  	  	ap.ParkingLabel.click();
	  	  	ap.Parking.click();
	  	  	ap.Floors.sendKeys("5");
	  	  	ap.FloorNo.sendKeys("3");
	  	  	ap.BalconyLabel.click();
	  	  	ap.NoBalcony.click();
	    }
}