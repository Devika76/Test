package com.commonfloor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ProDetailsPage {
	WebDriver driver;
	public ProDetailsPage(WebDriver driver)
	{
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	//property page
		@FindBy(how=How.XPATH, using="//*[@id=\"snbheaderId\"]/div/div/div[3]/div/div[1]/a")
		@CacheLookup
		WebElement PostPro;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"snbheaderId\"]")
		@CacheLookup
		WebElement PostButton;

 
	// basic details  
		@FindBy(how=How.XPATH, using="//*[@id=\"rent\"]")
		@CacheLookup
		WebElement Basicrent;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"property_typeLabel\"]")
		@CacheLookup
		WebElement ProType;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"Apartment\"]")
		@CacheLookup
		WebElement ProTypeLabel;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"possessionFrom\"]")
		@CacheLookup
		WebElement AvaiDate;
		
		@FindBy(how=How.XPATH, using="/html/body/div[11]/div[1]/table/tbody/tr[5]/td[4]")
		@CacheLookup
		WebElement ADate;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"post-ad-form\"]/div[3]/div[2]/div/div/div[5]/div/a")
		@CacheLookup
		WebElement Bcont;
		
		//Location Details
		
		@FindBy(how=How.XPATH, using="//*[@id=\"pap-basic-city\"]")
		@CacheLookup
		WebElement Lcity;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"pap-basic-city-select\"]/li[4]")
		@CacheLookup
		WebElement Scity;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"project_name\"]")
		@CacheLookup
		WebElement Aname;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"project_name\"]")
		@CacheLookup
		WebElement Apname;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"pap-location-projects-select\"]/li[1]")
		@CacheLookup
		WebElement Sname;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"post-ad-form\"]/div[3]/div[1]/div/div/div/div[5]/a")
		@CacheLookup
		WebElement Lcont;
		
				
		//property details
		@FindBy(how=How.XPATH, using="//*[@id=\"No_of_RoomsLabel\"]")
		@CacheLookup
		WebElement Norooms;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"2 BHK\"]")
		@CacheLookup
		WebElement Nobhk;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"carpetArea\"]")
		@CacheLookup
		WebElement Area;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"salePrice\"]")
		@CacheLookup
		WebElement Price;
		
		@FindBy(how=How.XPATH, using="//*[@id=\"maintenanceCharges\"]")
		@CacheLookup
		WebElement Maintenance;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"Deposit\"]")
		@CacheLookup
		WebElement Deposit;
		
				
		@FindBy(how=How.XPATH, using="//*[@id=\"BathroomsLabel\"]")
		@CacheLookup
		WebElement brooms;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"1\"]")
		@CacheLookup
		WebElement Nobrooms;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"FurnishedLabel\"]")
		@CacheLookup
		WebElement FurLabel;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"semi\"]")
		@CacheLookup
		WebElement SemiFur;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"parkingLabel\"]")
		@CacheLookup
		WebElement ParkingLabel;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"Both\"]")
		@CacheLookup
		WebElement Parking;
				
		@FindBy(how=How.XPATH, using="/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/div[3]/div[1]/form/div/div[1]/div[3]/div/div[4]/div/div[1]/input")
		@CacheLookup
		WebElement Floors;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"floorNo\"]")
		@CacheLookup
		WebElement FloorNo;
				
		@FindBy(how=How.XPATH, using="//*[@id=\"No_of_BalconyLabel\"]")
		@CacheLookup
		WebElement BalconyLabel;
				
		@FindBy(how=How.XPATH, using="/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/div[3]/div[1]/form/div/div[1]/div[3]/div/div[4]/div/div[3]/ul/li[2]")
		@CacheLookup
		WebElement NoBalcony;
		
	public WebElement getPostPro() {
		return PostPro;
		}
	public WebElement getPostButton() {
		return PostButton;
		}
	//basic details
	public WebElement getBasicrent() {
		return Basicrent;
		}
	public WebElement getProType() {
		return ProType;
		}
	public WebElement getProTypeLabel() {
		return ProTypeLabel;
		}
	public WebElement getAvaiDate() {
		return AvaiDate;
		}
	public WebElement getADate() {
		return ADate;
		}
	public WebElement getBcont() {
			return PostPro;
		}
	
	//location
	public WebElement getLcity() {
		return Lcity;
		}
	public WebElement getScity() {
		return Scity;
		}
	public WebElement getAname() {
		return Aname;
		}
	public WebElement getApname() {
		return Apname;
		}
	public WebElement getSname() {
		return Sname;
		}
	public WebElement getLcont() {
		return Lcont;
		}
	// property
	public WebElement getNorooms() {
		return Norooms;
		}
	public WebElement getNobhk() {
		return Nobhk;
		}
	public WebElement getArea() {
		return Area;
		}
	public WebElement getPrice() {
		return Price;
		}
	public WebElement getMaintenance() {
		return Maintenance;
		}
	public WebElement getDeposit() {
			return Deposit;
		}
	public WebElement getbrooms() {
		return brooms;
		}
	public WebElement getNobrooms() {
		return Nobrooms;
		}
	public WebElement getFurLabel() {
		return FurLabel;
		}
	public WebElement getSemiFur() {
		return SemiFur;
		}
	public WebElement getParkingLabel() {
		return ParkingLabel;
		}
	public WebElement getParking() {
			return Parking;
		}
	public WebElement getFloors() {
		return Floors;
		}
	public WebElement getFloorNo() {
		return FloorNo;
		}
	public WebElement getBalconyLabel() {
		return BalconyLabel;
		}
	public WebElement getNoBalcony() {
		return NoBalcony;
		}
}
