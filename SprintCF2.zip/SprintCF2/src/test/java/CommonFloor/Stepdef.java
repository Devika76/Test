package CommonFloor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Stepdef {
	public static WebDriver driver;
	@Given("User is on CommonFloor page")
	public void user_is_on_common_floor_page() {
	    System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.commonfloor.com/");
		driver.manage().window().maximize();
	}
	//sc2 given
	@Given("User is in the Home page of website")
	public void user_is_in_the_home_page_of_website() {
		System.out.println("User is in the Home Page of website");
	}
	//sc3
	@Given("User is in the signup Page of website")
	public void user_is_in_the_signup_page_of_website() {
		System.out.println("User is in the Signup Page of website");
	}
	//sc7 given
	@Given("User is in the Login Page of website")
	public void user_is_in_the_login_page_of_website() {
		System.out.println("User is in the login Page of website");
	}
	//sc10
	@Given("Logged-in User is in the Home page of website")
	public void logged_in_user_is_in_the_home_page_of_website() {
	  System.out.println("User logged in to the website");
	}
	//sc11
	@Given("User is in the Post Property Page")
	public void user_is_in_the_post_property_page() {
		System.out.println("User is in the post property Page of website");
	}
	//sc 1
	@When("Enter city to search")
	public void enter_city_to_search() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[2]/div[5]/div[9]/div/div/div/div/div[1]/input")).sendKeys("Chennai");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"cityFormModal\"]/div[2]/ul/li[9]")).click();
	}
	//sc3
	@When("click on the signup button")
	public void click_on_the_signup_button() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"login-details\"]")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-details\"]/ul/li[1]/a")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div[4]/div[1]/div/a")).click();
	}
	//sc4
	@When("Enter null on First name ")
	public void enter_null_on_first_name() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-name-id\"]")).sendKeys("");
	}
	@When("Enter null on Mobile")
	public void enter_null_on_mobile() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-mobile-id\"]")).sendKeys("");
	}
	@When("Click the Signup button")
	public void click_the_signup_button() throws InterruptedException {
		Thread.sleep(9000);
        driver.findElement(By.xpath("//*[@id=\"signupbutton\"]")).click();
		Thread.sleep(9000);
	}
	//sc5
	@When("Enter valid First name devika")
	public void enter_valid_first_name_devika() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-name-id\"]")).sendKeys("Devika");
	}
	@When("Enter valid  email id devidevika224@gmail.com")
	public void enter_valid_email_id_devidevika224_gmail_com1() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-email-id\"]")).sendKeys("devidevika224@gmail.com");
	}
	@When("Enter null passwordPuttupu@{int}")
	public void enter_null_password_puttupu(Integer int1) throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath(" //*[@id=\"login-password-id\"]")).sendKeys("Puttupu@1");
	}
	@When("Enter null Mobile8374191301")
	public void enter_null_mobile8374191301() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-mobile-id\"]")).sendKeys("8374191301");
	}
	@When("Enter valid city chennai")
	public void enter_valid_city_chennai() throws InterruptedException {
		Thread.sleep(9000);
        driver.findElement(By.xpath("//*[@id=\"signup-city\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"signup-city-list\"]/li[4]")).click();
	}
	@When("Enter valid usertype agent")
	public void enter_valid_usertype_agent() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div[7]/div/label[1]")).click();
	}	
	//sc6
	@When("click on the login button")
	public void click_on_the_login_button() throws InterruptedException {
		Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div[9]/a")).click();
	}
	//sc7
	@When("Enter null on email id ")
	public void enter_null_on_email_id() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-email-id\"]")).sendKeys("");
	}
	@When("Enter null on password")
	public void enter_null_on_password() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-password-id\"]")).sendKeys("");
	}
	//sc8
	@When("Enter invalid email id ab@{int}@gmail.com")
	public void enter_invalid_email_id_ab_gmail_com(Integer int1) throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-email-id\"]")).sendKeys("ab@1@gmail.com");
	}
	@When("Enter invalid passwordabcde")
	public void enter_invalid_passwordabcde() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-password-id\"]")).sendKeys("abcde");
	}

	//sc9
	@When("Enter valid email id devidevika224@gmail.com")
	public void enter_valid_email_id_devidevika224_gmail_com() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"login-email-id\"]")).clear();
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-email-id\"]")).sendKeys("devidevika224@gmail.com");
	}
	@When("Enter valid password Puttupu@{int}")
	public void enter_valid_password_puttupu(Integer int1) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"login-password-id\"]")).clear();
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"login-password-id\"]")).sendKeys("Puttupu@1");
	}
	@When("Click the Login button")
	public void click_the_login_button() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"loginForm\"]/input")).click();		
	}
	//sc10
	@When("Clicks on Post Property button")
	public void clicks_on_post_property_button() throws InterruptedException {
		Thread.sleep(9000);
        driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/div[1]/a")).click();
	}
	//sc11
	@When("Enter null on Rent under About the property section")
	public void enter_null_on_rent_under_about_the_property_section() throws InterruptedException {
		Thread.sleep(9000);
        driver.findElement(By.xpath("//*[@id=\"rent\"]")).click();;
	}
	@When("Enter null Type of Property ")
	public void enter_null_type_of_property() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"property_typeLabel\"]")).click();
        //driver.findElement(By.xpath("//*[@id=\"Apartment\"]")).click();
	}
	@When("Enter null Availbale From date ")
	public void enter_null_availbale_from_date() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"possessionFrom\"]")).click();
        driver.findElement(By.xpath("/html/body/div[11]/div[1]/table/tbody/tr[5]/td[4]")).click();
	}
	@When("Click the Continue button")
	public void click_the_continue_button() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"post-ad-form\"]/div[3]/div[2]/div/div/div[5]/div/a")).click();   
	}
	//sc12
	@When("Click on Rent under About the property section")
	public void click_on_rent_under_about_the_property_section() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"rent\"]")).click();
	}
	@When("Click on Type of Property Apartment")
	public void click_on_type_of_property_apartment() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"property_typeLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"Apartment\"]")).click();
	}
	@When("Clicks on Availbale From date {int}\\/{int}\\/{int}")
	public void clicks_on_availbale_from_date(Integer int1, Integer int2, Integer int3) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"possessionFrom\"]")).click();
        driver.findElement(By.xpath("/html/body/div[11]/div[1]/table/tbody/tr[5]/td[4]")).click();
	}
	//sc13
	@When("Enter null on City ")
	public void enter_null_on_city() throws InterruptedException {
		Thread.sleep(5000);
		System.out.print("City is not selected");
	}
	@When("Enter null on Building ")
	public void enter_null_on_building() throws InterruptedException {
		Thread.sleep(5000);
		System.out.print("name is not selected");
	}
	//sc14
	@When("User selects a city Chennai")
	public void user_selects_a_city_chennai() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"pap-basic-city\"]")).click();
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"pap-basic-city-select\"]/li[4]")).click();
	}

	@When("Enters a building name Vijay Nivas")
	public void enters_a_building_name_vijay_nivas() throws InterruptedException {
		Thread.sleep(9000);
		 driver.findElement(By.xpath("//*[@id=\"project_name\"]")).click();
			Thread.sleep(5000);
	     driver.findElement(By.xpath("//*[@id=\"project_name\"]")).sendKeys("Dev Prems Flat Besant Nagar");
			Thread.sleep(9000);
	     driver.findElement(By.xpath("//*[@id=\"pap-location-projects-select\"]/li[1]")).click();
	     Thread.sleep(5000);
	}
	@When("Click the Continue button on location page")
	public void click_the_continue_button_on_location_page() throws InterruptedException {
	     Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"post-ad-form\"]/div[3]/div[1]/div/div/div/div[5]/a")).click();
	}
	//sc15
	@When("User selects null on the BHK of the property <bhk>")
	public void user_selects_null_on_the_bhk_of_the_property_bhk() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"No_of_RoomsLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"2 BHK\"]")).click();
		}
	@When("Enter the null on Carpet Area of the property ")
	public void enter_the_null_on_carpet_area_of_the_property() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"carpetArea\"]")).sendKeys("");
	}
	@When("Enter the null on Rent of the property ")
	public void enter_the_null_on_rent_of_the_property() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"salePrice\"]")).sendKeys("");
	}
	@When("Enter the null on Monthly Maintenance of the property ")
	public void enter_the_null_on_monthly_maintenance_of_the_property() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"maintenanceCharges\"]")).sendKeys("");
	}
	@When("Enter the null on Security Deposit of the property ")
	public void enter_the_null_on_security_deposit_of_the_property() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"Deposit\"]")).sendKeys("");
	}
	@When("Enter the null on the number of Bathrooms avaiable for the property ")
	public void enter_the_null_on_the_number_of_bathrooms_avaiable_for_the_property() throws InterruptedException {
		Thread.sleep(5000);
		System.out.print("available bathroomes for the property is not selected");
	}
	@When("Enter the null on the furnished status of the property ")
	public void enter_the_null_on_the_furnished_status_of_the_property() throws InterruptedException {
		Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"FurnishedLabel\"]")).click();
	     driver.findElement(By.xpath("//*[@id=\"semi\"]")).click();
	}
	@When("Enter the null on the Reserved parking of the property ")
	public void enter_the_null_on_the_reserved_parking_of_the_property() throws InterruptedException {
		Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"parkingLabel\"]")).click();
	        driver.findElement(By.xpath("//*[@id=\"Both\"]")).click();
	}
	@When("Enter the null on Total floors of the apartment property <Tfloor>")
	public void enter_the_null_on_total_floors_of_the_apartment_property_tfloor() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"totalFloors\"]")).sendKeys("");
	}
	@When("Enter the null on floor number of property on  ")
	public void enter_the_null_on_floor_number_of_property_on() throws InterruptedException {
		Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"floorNo\"]")).sendKeys("");
	}
	@When("Enter the null on select the Balconies that are available in the property ")
	public void enter_the_null_on_select_the_balconies_that_are_available_in_the_property() throws InterruptedException {
		Thread.sleep(5000);
		//System.out.println("Null values entered");
		driver.findElement(By.xpath("//*[@id=\"No_of_BalconyLabel\"]")).click();
	        driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/div[3]/div[1]/form/div/div[1]/div[3]/div/div[4]/div/div[3]/ul/li[2]")).click();
			driver.findElement(By.xpath("//*[@id=\"formPostAd\"]/div/div[3]/input")).click();
			Thread.sleep(5000);
	}
	//sc16
	@When("User selects the BHK of the property <bhk>")
	public void user_selects_the_bhk_of_the_property_bhk() throws InterruptedException {
		Thread.sleep(9000);
        driver.findElement(By.xpath("//*[@id=\"No_of_RoomsLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"2 BHK\"]")).click();
	}
	@When("Enter the Carpet Area of the property chennai")
	public void enter_the_carpet_area_of_the_property_chennai() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"carpetArea\"]")).sendKeys("400");
	}
	@When("Enter the Rent of the property {int}")
	public void enter_the_rent_of_the_property(Integer int1) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"salePrice\"]")).sendKeys("8000");
	}
	@When("Enter the Monthly Maintenance of the property {int}")
	public void enter_the_monthly_maintenance_of_the_property(Integer int1) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"maintenanceCharges\"]")).sendKeys("500");
	}
	@When("Enter the Security Deposit of the property {int}")
	public void enter_the_security_deposit_of_the_property(Integer int1) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"Deposit\"]")).sendKeys("3000");
	}
	@When("Click to selects the number of Bathrooms avaiable for the property {int}")
	public void click_to_selects_the_number_of_bathrooms_avaiable_for_the_property(Integer int1) throws InterruptedException {
		Thread.sleep(5000); 
		driver.findElement(By.xpath("//*[@id=\"BathroomsLabel\"]")).click();
	        driver.findElement(By.xpath("//*[@id=\"1\"]")).click();
	}
	@When("Click to selects the furnished status of the property SemiFurnished")
	public void click_to_selects_the_furnished_status_of_the_property_semi_furnished() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"FurnishedLabel\"]")).click();
	        driver.findElement(By.xpath("//*[@id=\"semi\"]")).click();
	}
	@When("Click to select the Reserved parking of the property both")
	public void click_to_select_the_reserved_parking_of_the_property_both() throws InterruptedException {
		Thread.sleep(5000); 
		driver.findElement(By.xpath("//*[@id=\"parkingLabel\"]")).click();
	        driver.findElement(By.xpath("//*[@id=\"Both\"]")).click();
	}
	@When("Enter the Total floors of the apartment property <Tfloor>")
	public void enter_the_total_floors_of_the_apartment_property_tfloor() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/div[3]/div[1]/form/div/div[1]/div[3]/div/div[4]/div/div[1]/input")).sendKeys("5");
	}
	@When("Enter the floor number of property on  {int}")
	public void enter_the_floor_number_of_property_on(Integer int1) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"floorNo\"]")).sendKeys("3");
	}
	@When("Click to select the Balconies that are available in the property {int}")
	public void click_to_select_the_balconies_that_are_available_in_the_property(Integer int1) throws InterruptedException {
		Thread.sleep(5000); 
		driver.findElement(By.xpath("//*[@id=\"No_of_BalconyLabel\"]")).click();
	        driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/div[3]/div[1]/form/div/div[1]/div[3]/div/div[4]/div/div[3]/ul/li[2]")).click();
	}
	//sc 1 then
	@Then("check the title of the page")
	public void check_the_title_of_the_page() {
		String title  = driver.findElement(By.xpath("/html/head/title")).getText();
		if(title.contentEquals("commonfloor"))
			System.out.println("* Title Matched *");
		else System.out.println("* Title Not Matched *");
	}
	//sc2 then
	@Then("Print successful")
	public void print_successful() {
		System.out.println("Successful");
	}
	//sc4
	@Then("account should not be created successful")
	public void account_should_not_be_created_successful() {
		System.out.println("signup for account is UnSuccessful");
	}
	//sc7 then
	@Then("login should not be successful")
	public void login_should_not_be_successful() {
		System.out.println("Login is UnSuccessful");
	}
	//sc8
	@Then("Check if login is successful")
	public void check_if_login_is_successful() {
		System.out.println("Login Successful");
	}
	//sc10
	@Then("print successful")
	public void print_successful1() {
		System.out.println("Post property button is Successful");
	}
	//sc11
	@Then("Error msg should be displayed")
	public void error_msg_should_be_displayed() {
		System.out.println("Basic details is UnSuccessful");
	}
	//sc12 
	@Then("Property basic details should be added successfully")
	public void property_basic_details_should_be_added_successfully() {
		System.out.println("Basic details added Successful");
	}
	//sc14
	@Then("Property location details should be added successfully")
	public void property_location_details_should_be_added_successfully() {
		System.out.println("Location details added Successful");   
	}
	//sc16
	@Then("Property details should be added successfully")
	public void property_details_should_be_added_successfully() {
		System.out.println("property details added Successful");
	}
	
}
