package testngpackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CFTestNGClass 
{
	static WebDriver driver;
	@BeforeTest
	public static  void Browser()
	{
	    System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
	    driver = new ChromeDriver();	
	}
	@Test
	public void BrowserLogin() throws InterruptedException
	{
		driver.get("https://www.commonfloor.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	@Test
	public void HOME_PAGE() throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id=\"citySuggestInputHomePopup\"]")).sendKeys("Chennai");
		driver.findElement(By.xpath("/html/body/div[2]/div[5]/div[9]/div/div/div/div/div[2]/ul/li[9]")).click();
		Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"login-details\"]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"login-details\"]/ul/li[1]/a")).click();
        //signup
        driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div[4]/div[1]/div/a")).click();
        driver.findElement(By.xpath("//*[@id=\"login-name-id\"]")).sendKeys("Devika");
        driver.findElement(By.xpath("//*[@id=\"login-email-id\"]")).sendKeys("devidevika224@gmail.com");
        driver.findElement(By.xpath("//*[@id=\"login-mobile-id\"]")).sendKeys("8374191301");
        driver.findElement(By.xpath(" //*[@id=\"login-password-id\"]")).sendKeys("Puttupu@1");
        driver.findElement(By.xpath("//*[@id=\"signup-city\"]")).click();
        //login
        driver.findElement(By.xpath("//*[@id=\"signup-city-list\"]/li[4]")).click();
        driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div[7]/div/label[1]")).click();
        driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div[9]/a")).click();
        
        driver.findElement(By.xpath("//*[@id=\"login-email-id\"]")).sendKeys("devidevika224@gmail.com");
        driver.findElement(By.xpath("//*[@id=\"login-password-id\"]")).sendKeys("Puttupu@1");
        driver.findElement(By.xpath("//*[@id=\"loginForm\"]/input")).click();		
        Thread.sleep(9000);
        driver.findElement(By.xpath("/html/body/header/div/div/div[3]/div/div[1]/a")).click();
        Thread.sleep(3000);
	}
	@Test
	public void Property_BasicDetails() throws InterruptedException
	{
		//basic details
        driver.findElement(By.xpath("//*[@id=\"rent\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"property_typeLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"Apartment\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"possessionFrom\"]")).click();
        driver.findElement(By.xpath("/html/body/div[11]/div[1]/table/tbody/tr[5]/td[4]")).click();
        driver.findElement(By.xpath("//*[@id=\"post-ad-form\"]/div[3]/div[2]/div/div/div[5]/div/a")).click();   
        //location details
        driver.findElement(By.xpath("//*[@id=\"pap-basic-city\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"pap-basic-city-select\"]/li[4]")).click();
        driver.findElement(By.xpath("//*[@id=\"project_name\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"project_name\"]")).sendKeys("Vijay Glow, Beant Nagar");
        driver.findElement(By.xpath("//*[@id=\"pap-location-projects-select\"]/li[1]")).click();
        driver.findElement(By.xpath("//*[@id=\"post-ad-form\"]/div[3]/div[1]/div/div/div/div[5]/a")).click();
	}
        @Test
    	public void Property_PAGE() throws InterruptedException
    	{
        	//property details
        driver.findElement(By.xpath("//*[@id=\"No_of_RoomsLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"2 BHK\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"carpetArea\"]")).sendKeys("400");
        driver.findElement(By.xpath("//*[@id=\"salePrice\"]")).sendKeys("8000");
        driver.findElement(By.xpath("//*[@id=\"maintenanceCharges\"]")).sendKeys("500");
        driver.findElement(By.xpath("//*[@id=\"Deposit\"]")).sendKeys("3000");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"BathroomsLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"1\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"FurnishedLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"semi\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"parkingLabel\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"Both\"]")).click();
        driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/div[3]/div[1]/form/div/div[1]/div[3]/div/div[4]/div/div[1]/input")).sendKeys("5");
        driver.findElement(By.xpath("//*[@id=\"floorNo\"]")).sendKeys("3");
        driver.findElement(By.xpath("//*[@id=\"No_of_BalconyLabel\"]")).click();
	}
}